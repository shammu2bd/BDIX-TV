# Stage 16 — packet-buffer layout and RX ownership audit

**Status:** REVIEW_REQUIRED

- Stage 14 SHA-256: `0c86675b0a9e3dd3d5e41aa626c2fe1f4b9915450f5af7bbc808e8e9e595ba3a`
- Stage 15 SHA-256: `e132214d113fac85f0911d98de017a531a6df8406b535a1b7e9dad48d72f8e38`
- Stage 15 status: `PASS`

## Instance-size cross-check

| Class | Header-derived expected size | Stage 14 size | Result |
|---|---:|---:|---|
| `IOSkywalkPacket` | `0x78` | `0x70` | **MISMATCH** |
| `IOSkywalkPacketBuffer` | `0x90` | `0x90` | **PASS** |
| `IOSkywalkMemorySegment` | `0x78` | `0x78` | **PASS** |

## Getter field-offset evidence

Only a direct x86_64 `this` (`rdi`) displacement match is accepted. Absence of a direct match is `NEEDS_REVIEW`, not proof of a bad ABI.

## Legacy SDK header discrepancy

The vendored legacy `IOSkywalkPacket.h` annotated `mActualNumBuffers` at `0x60`. The target-build Stage 15 body for `getPacketBufferCount` reads a 32-bit value at `this+0x64`. The independent `getPacketBuffers` method must read the same offset; this audit now requires both methods to agree at `0x64`. The old comment is not treated as target-build ABI evidence.

| Method | 24H32 expected offset | Observed `this` displacements | Result |
|---|---:|---|---|
| `IOSkywalkPacket::getPacketBufferPool` | `0x40` | `0x40` | **PASS** |
| `IOSkywalkPacket::getPacketBufferCount` | `0x64` | `0x64` | **PASS** |
| `IOSkywalkPacket::getPacketBuffers` | `0x64` | `0x30`, `0x64` | **PASS** |
| `IOSkywalkPacketBuffer::getMemorySegment` | `0x58` | `0x58` | **PASS** |
| `IOSkywalkPacketBuffer::getMemorySegmentOffset` | `0x70` | `0x70` | **PASS** |
| `IOSkywalkPacketBuffer::getDataLength` | `0x7c` | `0x7c` | **PASS** |
| `IOSkywalkPacketBuffer::getDataOffset` | `0x80` | `0x80` | **PASS** |
| `IOSkywalkMemorySegment::getMemoryDescriptor` | `0x20` | `0x20` | **PASS** |
| `IOSkywalkMemorySegment::getVirtualAddress` | `0x30` | `0x30` | **PASS** |

## RX source/ownership invariants

| Check | Result |
|---|---|
| allocation is non-blocking and validates result | **PASS** |
| packet class, pool and single-buffer identity are checked | **PASS** |
| buffer, segment and memory descriptor null checks exist | **PASS** |
| span bounds and pointer-overflow checks precede memcpy | **PASS** |
| packet and buffer data offsets/lengths are verified before copy | **PASS** |
| completion status is set before packet is handed to caller | **PASS** |
| allocated packet is returned on conversion failure | **PASS** |
| mbuf is freed after workloop conversion on both success/failure | **PASS** |
| sink rejection returns packet to the pool | **PASS** |
| staged RX sink retains packet only in bounded owner ring | **PASS** |
| RX completion queue is explicitly kept behind publication fence | **PASS** |

## Open contracts — do not enable datapath yet

- Whether IOSkywalkMemorySegment/descriptor prepare-complete is required for this pool's allocated RX packet buffers.
- Exact ownership transition required before a future RX completion-queue submission.
- Exact queue registration and completion callback ABI required before publication.
- TX submission/completion queue handoff and teardown ordering.

## Safety boundary

This audit does not enable callbacks, register queues, submit packets, or publish an interface. A PASS only establishes the listed size/offset/source invariants; it does not establish Apple's undocumented mapping, prepare/complete, ownership, or completion semantics.
