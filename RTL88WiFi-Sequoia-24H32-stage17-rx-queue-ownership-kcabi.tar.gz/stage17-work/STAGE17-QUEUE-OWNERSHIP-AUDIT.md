# Stage 17 — queue lifecycle and RX/TX ownership evidence audit

**Status:** REVIEW_REQUIRED

- Stage 14 SHA-256: `0c86675b0a9e3dd3d5e41aa626c2fe1f4b9915450f5af7bbc808e8e9e595ba3a`
- Stage 15 SHA-256: `e132214d113fac85f0911d98de017a531a6df8406b535a1b7e9dad48d72f8e38`
- Stage 16 SHA-256: `183e1f6568f7e7f1eaad0e407833c1c5f8334c16ecf6bdeeecb016bf2268cc3d`
- Kernel collection SHA-256: `cd013c14a7f21dbb8181fb06c44e079de8646b6a674abe21f6e47f42e8979af3`

## Class method/disassembly coverage

| Class | Method symbols | Disassembled | Missing |
|---|---:|---:|---:|
| `IOSkywalkPacketQueue` | 67 | 2 | 65 |
| `IOSkywalkPacketBufferPool` | 74 | 2 | 72 |
| `IOSkywalkMemorySegment` | 31 | 2 | 29 |
| `IOSkywalkPacketBuffer` | 50 | 2 | 48 |
| `IOSkywalkPacket` | 59 | 2 | 57 |
| `IOSkywalkNetworkPacket` | 69 | 2 | 67 |
| `IOSkywalkRxSubmissionQueue` | 53 | 2 | 51 |
| `IOSkywalkRxCompletionQueue` | 52 | 2 | 50 |
| `IOSkywalkTxSubmissionQueue` | 64 | 2 | 62 |
| `IOSkywalkTxCompletionQueue` | 48 | 2 | 46 |
| `IOSkywalkInterface` | 38 | 2 | 36 |
| `IOSkywalkNetworkInterface` | 109 | 2 | 107 |
| `IOSkywalkEthernetInterface` | 68 | 3 | 65 |

## Source ownership and fail-closed checks

| Check | Result | Evidence |
|---|---|---|
| all four native queue callbacks remain fail-closed | **PASS** | TX/RX submission and completion callbacks return kIOReturnNotReady |
| TX submission validates packet view before declining acceptance | **PASS** | packet validation is present; native queue ownership is not accepted |
| all four queue objects are allocated with the matching factories | **PASS** | four queue factory calls found |
| queues are released before their backing pools | **PASS** | destroyQueues releases queue references before pools |
| driver implementation has no queue registration or enqueue calls | **PASS** | no registerEthernetInterface/enqueuePackets call sites |
| RX sink acceptance transfers ownership and rejection recycles packet | **PASS** | false sink result returns packet to pool; true transfers ownership |
| original RTW88 mbuf is freed after deferred conversion | **PASS** | source mbuf released in workloop drain |
| failed native packet construction recycles partial allocation | **PASS** | conversion failure returns packet to pool |
| controller RX sink transfers only into fixed-capacity packet ring | **PASS** | successful ring push is the only staged RX ownership transfer |
| pointer ring is bounded, power-of-two and rejects full pushes without allocation | **PASS** | fixed MPMC ring; failed push leaves ownership with producer |
| teardown is ordered after packet-path quiescence and RX drain | **PASS** | quiesce -> stop radio -> stop RX adapter -> recycle packets -> destroy queues |
| staged packet ring drains while pool is alive with disposal fallback | **PASS** | individual recycle plus pool disposal fallback |
| RX workloop source is removed before retained pool release | **PASS** | adapter removes source and drains mbuf ring before releasing pool |
| packet-path entry increments in-flight count and rechecks active state | **PASS** | entry race is rolled back when quiesce wins |
| quiesce prevents owner teardown while packet operations are in flight | **PASS** | in-flight operations keep owners live for retry |
| TX adapter retains packet before reserving bounded completion ticket | **PASS** | packet retained until deferred ticket drain |
| RTW88 completion callback only publishes ticket state | **PASS** | backend callback does not call Skywalk or release OSObjects |
| TX packet retain is released only after deferred completion sink returns | **PASS** | deferred context runs sink before ticket and packet release |
| native interface start refuses publication; latent activation is only in its gated enable callback | **PASS** | InfraInterface::start returns false without super::start; enable contains the sole activation call after powerOn; no register/enqueue call sites |

## Unresolved contracts

- RX completion enqueue ownership transition and callback packet-array semantics.
- RX submission dequeue/replenishment ownership and retry semantics.
- TX completion queue acceptance and packet-retain transfer semantics.
- Packet-buffer and memory-segment prepare/complete requirements for configured pool options.
- Ethernet interface registration success/failure ownership and deregistration order.
- Queue enable/disable/synchronize and teardown order with in-flight callbacks.

## Activation gate

**BLOCKED.** This stage collects the exact 24H32 methods and verifies that the project remains fail-closed. It does not infer queue ownership from method names alone, and it does not enable the datapath.
